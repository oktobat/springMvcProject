package com.mycompany.myshop.board;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/board")
public class CustomerCenterController {

	@GetMapping("/customerCenter")
	public String customerCenter(Model model) {
		String nextPage = "board/customer_center";
		return nextPage;
	}
	
	
}
