package com.mycompany.myshop.review;

import java.util.List;

import org.springframework.dao.DataAccessException;

public interface ReviewService {

	public int registerReviewConfirm(ReviewVo reviewVo, List<String> images) throws DataAccessException;
	public int removeReviewConfirm(int review_no) throws DataAccessException;
	public void modifyReviewConfirm(ReviewVo reviewVo, List<String> images) throws DataAccessException;
	public List<ReviewVo> photoReviewData(int pNum, int scale, long g_no) throws DataAccessException;
	public int photoReviewCount(long g_no) throws DataAccessException;
	public List<ReviewVo> textReviewData(int pNum, int scale, long g_no) throws DataAccessException;
	public int textReviewCount(long g_no) throws DataAccessException;
	public List<ReviewVo> myReviewList(int m_no) throws DataAccessException;
}
