package com.mycompany.myshop.review;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class ReviewDaoImpl implements ReviewDao {

	@Autowired
	private SqlSession sqlSession;

	@Override
	public int insertNewReview(ReviewVo reviewVo) {
		int result = sqlSession.insert("mapper.review.insertNewReview", reviewVo);
		if (result==0) {
			throw new RuntimeException("리뷰 삽입 실패");
		}
		return reviewVo.getReview_no();
	}
	
	@Override
	public int deleteReview(int review_no) {
		return sqlSession.delete("mapper.review.deleteReview", review_no);
	}
	
	@Override
	public int updateReview(ReviewVo reviewVo) {
		return sqlSession.update("mapper.review.updateReview", reviewVo);
	}

	@Override
	public int insertReviewImage(Map<String, Object> map) {
		int result = sqlSession.insert("mapper.review.insertReviewImage", map);
		if (result==0) {
			throw new RuntimeException("이미지 삽입 실패");
		}
		return result;
	}

	@Override
	public List<ReviewVo> selectPhotoReviewList(int pNum, int scale, long g_no) {
		List<ReviewVo> photoReviewList = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("pNum", pNum);
		map.put("scale", scale);
		map.put("g_no", g_no);
		photoReviewList = sqlSession.selectList("mapper.review.selectPhotoReviewList", map);
		return photoReviewList.size()>0 ? photoReviewList : null;
	}

	@Override
	public int selectPhotoReviewCount(long g_no) {
		return sqlSession.selectOne("mapper.review.selectPhotoReviewCount", g_no);
	}

	@Override
	public List<ReviewVo> selectTextReviewList(int pNum, int scale, long g_no) {
		List<ReviewVo> textReviewList = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("pNum", pNum);
		map.put("scale", scale);
		map.put("g_no", g_no);
		textReviewList = sqlSession.selectList("mapper.review.selectTextReviewList", map);
		return textReviewList.size()>0 ? textReviewList : null;
	}

	@Override
	public int selectTextReviewCount(long g_no) {
		return sqlSession.selectOne("mapper.review.selectTextReviewCount", g_no);
	}

	@Override
	public List<ReviewVo> selectMyReviewList(int m_no) {
		List<ReviewVo> reviewVos = new ArrayList<>();
		reviewVos = sqlSession.selectList("mapper.review.selectMyReviewList", m_no);
		return reviewVos.size()>0 ? reviewVos : null;
	}

		
	
}
