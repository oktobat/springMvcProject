package com.mycompany.myshop.review;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class ReviewImageVo {

	private long img_no;
	private int review_no;
	private String img_url;
	private Timestamp img_reg_date;
	private Timestamp img_mod_date;
	
}
