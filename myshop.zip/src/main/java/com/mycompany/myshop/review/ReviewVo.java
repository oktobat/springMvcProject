package com.mycompany.myshop.review;

import java.sql.Timestamp;

import lombok.Data;

@Data
public class ReviewVo {
	private int review_no;
	private String comment;
	private int rating;
	private long g_no;
	private long order_detail_no;
	private int m_no;
	private Timestamp rv_reg_date;
	private Timestamp rv_mod_date;
	
	private long img_no;
	private String img_url;
	private String m_email;
	private String g_name;
	private String images;
}
