package com.mycompany.myshop.goods;

import java.util.List;
import java.util.Map;

import org.springframework.dao.DataAccessException;

public interface GoodsService {
	
	public String registerGoodsConfirm(Map<String, Object> newGoodsMap) throws DataAccessException;
	public List<GoodsVo> categoryData(int pNum, int scale, String g_category) throws DataAccessException;
	public int goodsListCount(String g_category) throws DataAccessException;
	public int cartIn(Map<String, Integer> map) throws DataAccessException;
	public int cartGoodsCount(int m_no) throws DataAccessException;
	public List<CartVo> cartList(int m_no) throws DataAccessException;
	public int cartUpdate(Map<String, Integer> map) throws DataAccessException;
	public int cartDelete(long cart_no) throws DataAccessException;
	public GoodsVo detailInfo(long g_no) throws DataAccessException;
	public List<GoodsImageVo> detailImage(long g_no) throws DataAccessException;
	public List<GoodsVo> searchGoods(String keyword) throws DataAccessException;
	public List<GoodsVo> mainGoods(String g_type) throws DataAccessException;
	public int modifyGoodsConfirm(GoodsVo goodsVo) throws DataAccessException;
	public int removeGoods(long g_no) throws DataAccessException;
	public int removeImage(long img_no) throws DataAccessException;
	public int updateImage(GoodsImageVo goodsImageVo) throws DataAccessException;
	public int registerImage(GoodsImageVo goodsImageVo) throws DataAccessException;
	public int cartCheckedRemove(List<Long> cartNoList) throws DataAccessException;
	public List<CartVo> checkoutList(List<Long> cartNos) throws DataAccessException;
	public List<OrderVo> myOrderList(int m_no) throws DataAccessException;
	public List<OrderDetailVo> myOrderDetail(long order_no) throws DataAccessException;
	public int getCartItemQty(int m_no, long g_no) throws DataAccessException;
	public int updateGoodsInventory(OrderDetailVo orderDetailItem) throws DataAccessException;
}
