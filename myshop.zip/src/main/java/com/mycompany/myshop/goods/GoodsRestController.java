package com.mycompany.myshop.goods;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.mycompany.myshop.member.MemberVo;
import com.mycompany.myshop.util.MultiUploadFileService;
import com.mycompany.myshop.util.PageVo;
import com.mycompany.myshop.util.UploadFileService;

@RestController
@RequestMapping("/goods")
public class GoodsRestController {

	@Autowired
	private GoodsService goodsService;
	
	@Autowired
	private MultiUploadFileService multiUploadFileService;
	
	@Autowired
	private UploadFileService uploadFileService;
	
	
	@PostMapping(value="/registerGoodsConfirm", produces="text/plain; charset=UTF-8")
	public String registerGoodsConfirm(@RequestPart(value="item") GoodsVo goodsVo, @RequestPart(value="file", required=false) List<MultipartFile> files) {
		Map<String, Object> newGoodsMap = new HashMap<>();
		newGoodsMap.put("item", goodsVo);
		if (files.size()>0) {
			List<String> imageFileList = multiUploadFileService.multiUpload(files);
			newGoodsMap.put("imageFileList", imageFileList);
		}
		String message = goodsService.registerGoodsConfirm(newGoodsMap);
		return message;
	}
	
	@GetMapping(value="/categoryData", produces="application/json")
	public Map<String, Object> categoryData(@RequestParam("pageGroup") int pageGroup, @RequestParam("pageNum") int pageNum, HttpSession session) {
		String g_category = (String) session.getAttribute("currentCategory");
		int amount = 10; 
		int pageNums = 10;
		Map<String, Object> map = new HashMap<>();
		List<GoodsVo> goodsList = goodsService.categoryData((pageNum-1)*amount, amount, g_category);
		int totArticles = goodsService.goodsListCount(g_category);
		PageVo pageVo = new PageVo(pageGroup, pageNum, amount, pageNums, totArticles);
		map.put("goodsList", goodsList);
		map.put("pageVo", pageVo);
		return map;
	}
	
	@PostMapping(value="/cartIn", consumes="application/json", produces="application/json")
	public Map<String, Integer> cartIn(@RequestBody Map<String, Integer> map, HttpSession session) throws Exception {
		MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
		int m_no = mvo.getM_no();
		map.put("m_no", m_no);
		long g_no = map.get("g_no");
		int g_inventory = map.get("g_inventory");
		int cart_qty = map.get("cart_qty");
		int result;
		int existingCartQty = goodsService.getCartItemQty(m_no, g_no);
		if (existingCartQty+cart_qty <= g_inventory) {
			result = goodsService.cartIn(map);  // 1 or -1
		} else {
			result = 0;
		}
		Map<String, Integer> cartCount = new HashMap<>();
		if (result>0) {
			int count = goodsService.cartGoodsCount(m_no);
			cartCount.put("cartCount", count);
			cartCount.put("result", result);
		} else if (result<0) {
			cartCount.put("cartCount", -1);
			cartCount.put("result", result);
		} else {
			cartCount.put("cartCount", g_inventory-existingCartQty);
			cartCount.put("result", result);
		}
		return cartCount;
	}
	
	@GetMapping(value="/cartCount", produces="application/json")
	public Map<String, Integer> cartCount(HttpSession session) throws Exception {
		MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
		int m_no = mvo.getM_no();
		Map<String, Integer> cartCount = new HashMap<>();
		int count = goodsService.cartGoodsCount(m_no);
		cartCount.put("cartCount", count);
		return cartCount;
	}
	
	@PutMapping(value="/cartUpdate", consumes="application/json", produces="text/plain; charset=UTF-8")
	public String cartUpdate(@RequestBody Map<String, Integer> map) {
		int result = goodsService.cartUpdate(map);
		String message = null;
		if (result>0) {
			message = "성공";
		} else {
			message = "실패";
		}
		return message;
	}
	
	@DeleteMapping(value="/cartDelete", produces="application/json")
	public Map<String, Integer> cartDelete(@RequestParam("cart_no") long cart_no, HttpSession session) {
		int result = goodsService.cartDelete(cart_no);
		Map<String, Integer> cartCount = new HashMap<>();
		if (result>0) {
			MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
			int m_no = mvo.getM_no();
			int count = goodsService.cartGoodsCount(m_no);
			cartCount.put("cartCount", count);
		} else {
			cartCount.put("cartCount", -1);
		}
		return cartCount;
	}
	
	@GetMapping(value="/detailImage", produces="application/json")
	public Map<String, List<GoodsImageVo>> detailImage(@RequestParam("g_no") long g_no) {
		List<GoodsImageVo> imageList = goodsService.detailImage(g_no);
		Map<String, List<GoodsImageVo>> map = new HashMap<>();
		map.put("imageList", imageList);
		return map;
	}
	
	@GetMapping(value="/mainGoods", produces="application/json")
	public Map<String, List<GoodsVo>> mainGoods(@RequestParam("g_type") String g_type) {
		Map<String, List<GoodsVo>> map = new HashMap<>();
		List<GoodsVo> mainList = new ArrayList<>();
		mainList = goodsService.mainGoods(g_type);
		System.out.println(mainList.toString());
		map.put("mainList", mainList);
		return map;
	}
	
	@PostMapping(value="/modifyGoodsConfirm", produces="application/json")
	public Map<String, Integer> modifyGoodsConfirm(GoodsVo goodsVo) {
		System.out.println("상품수정정보"+goodsVo);
		Map<String, Integer> map = new HashMap<>();
		int result = goodsService.modifyGoodsConfirm(goodsVo);
		map.put("result", result);
		return map; 
	}
	
	@DeleteMapping(value="/removeGoods", produces="application/json")
	public Map<String, Integer> removeGoods(@RequestParam("g_no") long g_no) {
		Map<String, Integer> map = new HashMap<>();
		int result = goodsService.removeGoods(g_no);
		map.put("result", result);
		return map; 
	}
	
	@PostMapping(value="/removeImage", produces="application/json")
	public Map<String, Integer> removeImage(@RequestParam("img_no") long img_no) {
		Map<String, Integer> map = new HashMap<>();
		int result = goodsService.removeImage(img_no);
		map.put("result", result);
		return map; 
	}
	
	@PostMapping(value="/updateImage", produces="application/json")
	public Map<String, Integer> updateImage(@RequestPart(value="image") MultipartFile file, @RequestParam("img_no") long img_no, GoodsImageVo goodsImageVo){
		System.out.println(file);
		System.out.println(img_no);
		Map<String, Integer> map = new HashMap<>();
		String changeImage = uploadFileService.upload(file);
		goodsImageVo.setImg_no(img_no);
		goodsImageVo.setImg_url(changeImage);
		int result = goodsService.updateImage(goodsImageVo);
		map.put("result", result);
		return map; 
	}
	
	@PostMapping(value="/registerImage", produces="application/json")
	public Map<String, Integer> registerImage(@RequestPart(value="image") MultipartFile file, @RequestParam("g_no") long g_no, GoodsImageVo goodsImageVo){
		Map<String, Integer> map = new HashMap<>();
		String addImage = uploadFileService.upload(file);
		goodsImageVo.setImg_no(g_no);
		goodsImageVo.setImg_url(addImage);
		int result = goodsService.registerImage(goodsImageVo);
		map.put("result", result);
		return map; 
	}
	
	@DeleteMapping(value="/cartCheckedRemove", produces="application/json")
	public Map<String, Integer> cartCheckedRemove(@RequestBody Map<String, List<Long>> map, HttpSession session) {
		List<Long> cartNoList = map.get("checkedList");
		Map<String, Integer> cartCount = new HashMap<>();
		int result = goodsService.cartCheckedRemove(cartNoList);
		if (result>0) {
			MemberVo mvo = (MemberVo) session.getAttribute("loginedMemberVo");
			int m_no = mvo.getM_no();
			int count = goodsService.cartGoodsCount(m_no);
			cartCount.put("cartCount", count);
		} else {
			cartCount.put("cartCount", -1);
		}
		return cartCount;
	}
	
}
