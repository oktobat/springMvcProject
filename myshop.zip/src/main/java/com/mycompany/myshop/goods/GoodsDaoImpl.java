package com.mycompany.myshop.goods;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

@Repository
public class GoodsDaoImpl implements GoodsDao {

	@Autowired
	private SqlSession sqlSession;
	
	@Override
	public long insertNewGoods(GoodsVo goodsVo) {
		sqlSession.insert("mapper.goods.insertNewGoods", goodsVo);
		return goodsVo.getG_no();
	}

	@Override
	public int insertDetailImage(Map<String, Object> map) {
		int result = -1;
		result = sqlSession.insert("mapper.goods_image.insertDetailImage", map);
		return result;
	}

	@Override
	public List<GoodsVo> selectGoodsList(int pNum, int scale, String g_category) {
		List<GoodsVo> goodsList = new ArrayList<>();
		Map<String, Object> map = new HashMap<>();
		map.put("pNum", pNum);
		map.put("scale", scale);
		map.put("g_category", g_category);
		goodsList = sqlSession.selectList("mapper.goods.selectGoodsList", map);
		return goodsList.size()>0 ? goodsList : null;
	}

	@Override
	public int selectGoodsCount(String g_category) {
		int result = -1;
		result = sqlSession.selectOne("mapper.goods.selectGoodsCount", g_category);
		return result;
	}

	@Override
	public int insertCart(Map<String, Integer> map) {
		int result = -1;
		result = sqlSession.insert("mapper.cart.insertCart", map);
		return result;
	}

	@Override
	public int selectCartCount(int m_no) {
		int result = sqlSession.selectOne("mapper.cart.selectCartCount", m_no);
		return result; 
	}

	@Override
	public List<CartVo> selectCartList(int m_no) {
		List<CartVo> cartList = new ArrayList<>();
		cartList = sqlSession.selectList("mapper.cart.selectCartList", m_no);
		return cartList.size()>0 ? cartList : null;
	}

	@Override
	public int updateCart(Map<String, Integer> map) {
		int result = -1;
		result = sqlSession.update("mapper.cart.updateCart", map);
		return result;
	}

	@Override
	public int deleteCartItem(long cart_no) {
		int result = -1;
		result = sqlSession.delete("mapper.cart.deleteCartItem", cart_no);
		return result;
	}

	@Override
	public GoodsVo selectGoods(long g_no) {
		List<GoodsVo> goodsVos = new ArrayList<>();
		goodsVos = sqlSession.selectList("mapper.goods.selectGoods", g_no);
		return goodsVos.size()>0 ? goodsVos.get(0) : null;
	}

	@Override
	public List<GoodsImageVo> selectImages(long g_no) {
		List<GoodsImageVo> imageList = null;
		imageList = sqlSession.selectList("mapper.goods_image.selectImages", g_no);
		return imageList.size()>0 ? imageList : null;
	}

	@Override
	public List<GoodsVo> selectSearchGoods(String keyword) {
		List<GoodsVo> goodsVos = new ArrayList<>();
		goodsVos = sqlSession.selectList("mapper.goods.selectSearchGoods", keyword);
		return goodsVos.size()>0 ? goodsVos : null;
	}

	@Override
	public List<GoodsVo> selectMainGoods(String g_type) {
		List<GoodsVo> mainList = new ArrayList<>();
		mainList = sqlSession.selectList("mapper.goods.selectMainGoods", g_type);
		return mainList.size()>0 ? mainList : null;
	}

	@Override
	public int updateGoods(GoodsVo goodsVo) {
		int result = -1;
		result = sqlSession.update("mapper.goods.updateGoods", goodsVo);
		return result;
	}

	@Override
	public int deleteGoodsImage(long img_no) {
		int result = -1;
		result = sqlSession.delete("mapper.goods_image.deleteGoodsImage", img_no);
		return result;
	}

	@Override
	public int updateImage(GoodsImageVo goodsImageVo) {
		int result = -1;
		result = sqlSession.update("mapper.goods_image.updateImage", goodsImageVo);
		return result;
	}

	@Override
	public int insertImage(GoodsImageVo goodsImageVo) {
		int result = -1;
		result = sqlSession.insert("mapper.goods_image.insertImage", goodsImageVo);
		return result;
	}

	@Override
	public int deleteGoods(long g_no) {
		int result = -1;
		result = sqlSession.delete("mapper.goods.deleteGoods", g_no);
		return result;
	}

	@Override
	public int deleteCheckedCart(List<Long> cartNoList) {
		int result = -1;
		result = sqlSession.delete("mapper.cart.deleteCheckedCart", cartNoList);
		return result;
	}

	@Override
	public List<CartVo> selectCheckoutList(List<Long> cartNos) {
		List<CartVo> cartVos = new ArrayList<>();
		cartVos = sqlSession.selectList("mapper.cart.selectCheckoutList", cartNos);
		return cartVos.size() > 0 ? cartVos : null; 
	}

	@Override
	public long insertOrder(OrderVo orderVo) {
		sqlSession.insert("mapper.order.insertOrder", orderVo);
		return orderVo.getOrder_no();
	}

	@Override
	public int insertOrderDetail(long orderNo, List<OrderDetailVo> orderDetailItems) {
		Map<String, Object> orderDetailMap = new HashMap<>();
		int result = -1;
		orderDetailMap.put("order_no", orderNo);
		orderDetailMap.put("orderDetailItems", orderDetailItems);
		result = sqlSession.insert("mapper.order_detail.insertOrderDetail", orderDetailMap);
		return result;
	}

	@Override
	public List<OrderVo> selectMyOrderList(int m_no) {
		List<OrderVo> orderVos = new ArrayList<>();
		orderVos = sqlSession.selectList("mapper.order.selectMyOrderList", m_no);
		return orderVos.size()>0 ? orderVos : null;
	}

	@Override
	public List<OrderDetailVo> selectMyOrderDetailList(long order_no) {
		List<OrderDetailVo> orderDetailList = new ArrayList<>();
		orderDetailList = sqlSession.selectList("mapper.order_detail.selectMyOrderDetailList", order_no);
		return orderDetailList.size()>0? orderDetailList : null;
	}

	@Override
	public int updateGoodsInventory(OrderDetailVo orderDetailItem) {
		int	result = sqlSession.update("mapper.goods.updateGoodsInventory", orderDetailItem);
		return result;
	}

	@Override
	public int selectCartItemQty(int m_no, long g_no) {
		Map<String, Object> map = new HashMap<>();
		map.put("m_no", m_no);
		map.put("g_no", g_no);
		return sqlSession.selectOne("mapper.cart.selectCartItemQty", map);
	}

	@Override
	public int updateOrderDetailReviewed(long order_detail_no) {
		int result = sqlSession.update("mapper.order_detail.updateOrderDetailReviewed", order_detail_no);
		if (result==0) {
			throw new RuntimeException("업데이트 실패");
		}
		return result;
	}

	

}
