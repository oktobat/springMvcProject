package com.mycompany.myshop.goods;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class CartService {

	@Autowired
	private GoodsDao goodsDao;
	
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor={RuntimeException.class, IllegalArgumentException.class, Exception.class})
	public int deleteCart(List<Long> orderCartNos) {
		try { 
			int result = goodsDao.deleteCheckedCart(orderCartNos);
			return result;
		} catch (RuntimeException e) {
	        log.error("Insert error", e);
	        throw e;
	    }
	}
	
}
