package com.mycompany.myshop.goods;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class GoodsServiceImpl implements GoodsService {

	@Autowired
	private GoodsDao goodsDao;
	
	@Override
	public String registerGoodsConfirm(Map<String, Object> newGoodsMap) throws DataAccessException {
		GoodsVo goods = (GoodsVo) newGoodsMap.get("item");
		List<String> images = (List<String>) newGoodsMap.get("imageFileList");
		long g_no = goodsDao.insertNewGoods(goods);
		System.out.println("상품번호 : "+g_no);
		int result = 0;
		String message = null;
		System.out.println("이미지스:"+images);
		if ( images!=null && g_no>0) {
			Map<String, Object> map = new HashMap<>();
			map.put("images", images);
			map.put("g_no", g_no);
			result = goodsDao.insertDetailImage(map);
		}
		if (g_no>0) {
			if (result>0) {
				message = "성공";
			} else {
				message = "부분성공";
			}
		} else {
			message = "실패";
		}
		return message;
	}

	@Override
	public List<GoodsVo> categoryData(int pNum, int scale, String g_category) throws DataAccessException {
		return goodsDao.selectGoodsList(pNum, scale, g_category);
	}

	@Override
	public int goodsListCount(String g_category) throws DataAccessException {
		return goodsDao.selectGoodsCount(g_category);
	}

	@Override
	public int cartIn(Map<String, Integer> map) throws DataAccessException {
		return goodsDao.insertCart(map);
	}

	@Override
	public int cartGoodsCount(int m_no) throws DataAccessException {
		return goodsDao.selectCartCount(m_no);
	}

	@Override
	public List<CartVo> cartList(int m_no) throws DataAccessException {
		return goodsDao.selectCartList(m_no);
	}

	@Override
	public int cartUpdate(Map<String, Integer> map) throws DataAccessException {
		return goodsDao.updateCart(map);
	}

	@Override
	public int cartDelete(long cart_no) throws DataAccessException {
		return goodsDao.deleteCartItem(cart_no);
	}

	@Override
	public GoodsVo detailInfo(long g_no) throws DataAccessException {
		return goodsDao.selectGoods(g_no);
	}

	@Override
	public List<GoodsImageVo> detailImage(long g_no) throws DataAccessException {
		return goodsDao.selectImages(g_no);
	}

	@Override
	public List<GoodsVo> searchGoods(String keyword) throws DataAccessException {
		return goodsDao.selectSearchGoods(keyword);
	}

	@Override
	public List<GoodsVo> mainGoods(String g_type) throws DataAccessException {
		return goodsDao.selectMainGoods(g_type);
	}

	@Override
	public int modifyGoodsConfirm(GoodsVo goodsVo) throws DataAccessException {
		return goodsDao.updateGoods(goodsVo);
	}
	
	@Override
	public int removeImage(long img_no) throws DataAccessException {
		return goodsDao.deleteGoodsImage(img_no);
	}

	@Override
	public int updateImage(GoodsImageVo goodsImageVo) throws DataAccessException {
		return goodsDao.updateImage(goodsImageVo);
	}

	@Override
	public int registerImage(GoodsImageVo goodsImageVo) throws DataAccessException {
		return goodsDao.insertImage(goodsImageVo);
	}

	@Override
	public int removeGoods(long g_no) throws DataAccessException {
		return goodsDao.deleteGoods(g_no);
	}

	@Override
	public int cartCheckedRemove(List<Long> cartNoList) throws DataAccessException {
		return goodsDao.deleteCheckedCart(cartNoList);
	}

	@Override
	public List<CartVo> checkoutList(List<Long> cartNos) throws DataAccessException {
		return goodsDao.selectCheckoutList(cartNos);
	}

	@Override
	public List<OrderVo> myOrderList(int m_no) throws DataAccessException {
		return goodsDao.selectMyOrderList(m_no);
	}

	@Override
	public List<OrderDetailVo> myOrderDetail(long order_no) throws DataAccessException {
		return goodsDao.selectMyOrderDetailList(order_no);
	}

	@Override
	@Transactional(propagation = Propagation.REQUIRED, rollbackFor = {RuntimeException.class, IllegalArgumentException.class, Exception.class})
	public int updateGoodsInventory(OrderDetailVo orderDetailItem) throws DataAccessException {
		try { 
			int result = goodsDao.updateGoodsInventory(orderDetailItem);
			if (result==0) {
				throw new IllegalArgumentException("재고가 부족한 상품이 있습니다.");
			}
			return result;
		} catch (IllegalArgumentException e) {
	        log.error("재고 부족 오류", e);
	        throw e;
	    } catch (RuntimeException e) {
	        log.error("Insert error", e);
	        throw e;
	    }
	}

	@Override
	public int getCartItemQty(int m_no, long g_no) throws DataAccessException {
		return goodsDao.selectCartItemQty(m_no, g_no);
	}

		
	

	
}
