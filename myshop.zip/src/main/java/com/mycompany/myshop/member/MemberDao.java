package com.mycompany.myshop.member;

import java.util.Map;

public interface MemberDao {
	
	public int insertMember(MemberVo memberVo);
	public Map<String, Object> selectMember(MemberVo memberVo);
	public int updateMember(MemberVo memberVo);
	public int deleteMember(int m_no);
}
