package com.mycompany.myshop.member;

import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/member")
public class MemberController {

	@Autowired
	private MemberService memberService;
	
	@PostMapping("/joinConfirm")
	public String joinConfirm(MemberVo memberVo, HttpSession session) {
		String nextPage = "redirect:/";
		int result = memberService.joinConfirm(memberVo);
		session.invalidate();
		return nextPage;
	}
	
	@PostMapping("/loginConfirm")
	public String loginConfirm(MemberVo memberVo, HttpSession session, Model model) {
		String nextPage = "redirect:/";
		Map<String, Object> map  = memberService.loginConfirm(memberVo);
		
		if (map.get("findMember") != null) {
			session.removeAttribute("message");
			MemberVo findMember = (MemberVo) map.get("findMember");
			session.setAttribute("loginedMemberVo", findMember);
			if (findMember.getM_email().equals("tsalt@hanmail.net")) {
				session.setAttribute("admin", true);
			}
		} else {
			session.setAttribute("message", map.get("message"));
		}
		return nextPage;
	}
	
	// 로그아웃
	@GetMapping("/logoutConfirm")
	public String logoutConfirm(HttpSession session) {
		String nextPage = "redirect:/";
		session.invalidate();
		return nextPage;
	}
	
	// 정보수정
	@GetMapping("/modifyMemberForm")
	public String modifyMemberForm(HttpSession session) {
		String nextPage = "member/modify_member_form";
		session.setAttribute("currentCategory", "");
		return nextPage;
	}
	
	@PostMapping("/modifyMemberConfirm")
	public String modifyMemberConfirm(MemberVo memberVo, HttpSession session) {
		String nextPage = "redirect:/";
		int result = memberService.modifyMemberConfirm(memberVo);
		if (result>0) {
			session.setAttribute("loginedMemberVo", memberVo);
		}
		return nextPage;
	}
	
	@PostMapping("/removeMemberConfirm")
	public String removeMemberConfirm(MemberVo memberVo, HttpSession session) {
		String nextPage = "redirect:/";
		int result = memberService.removeMemberConfirm(memberVo.getM_no());
		if (result>0) {
			session.invalidate();
		}
		return nextPage;
	}
	
}
