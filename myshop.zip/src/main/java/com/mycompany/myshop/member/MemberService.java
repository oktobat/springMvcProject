package com.mycompany.myshop.member;

import java.util.Map;

import org.springframework.dao.DataAccessException;

public interface MemberService {
	
	public int joinConfirm(MemberVo memberVo) throws DataAccessException;
	public Map<String, Object> loginConfirm(MemberVo memberVo) throws DataAccessException;
	public int modifyMemberConfirm(MemberVo memberVo) throws DataAccessException;
	public int removeMemberConfirm(int m_no) throws DataAccessException;
	
}
